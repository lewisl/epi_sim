# Ring spreader-migration experiments — run plan & predicted patterns

You already have in `sample_parameters/ring_experiment/`:
`rings_highout.json`, `rings_lowout.json`, `rings_oneleaky.json`,
`seed_norings.json`, `seed_rings.json`.

Two added configs (copy into the same dir):
`rings_one_exporter.json`, `rings_gradient.json`.

All use the same `config_rings.json` driver (180 days, vax off, single locale).
Swap only the `"rings"` field to point at each ring file, keep seed + everything
else fixed so differences are attributable to migration, not noise. Use the SAME
rng seed across runs.

## What `out_ring_prob` actually does (so you read the columns right)

From spread.cpp: `p_out = out_ring_prob[spreader_ring][spreader_agegrp]` is the
fraction of a spreader's contacts drawn from OUTSIDE its ring; those out-contacts
are spread uniformly across all OTHER rings. Key consequences:

- A ring's `out_ring_prob` governs where ITS spreaders go, NOT how protected it is.
- `out_ring_prob = 0` means "my spreaders stay home" — it does NOT stop a ring from
  RECEIVING other rings' exported spreaders. A sealed ring is a receiver, not a
  bunker.
- So the protected ring is the one whose own spreaders leave (infection spent
  elsewhere) AND that few others target. The victim ring is one that exports little
  but receives a lot.

## Columns to capture

Per run, serialize per-ring deaths and infections at total bucket, plus the
aggregate, e.g.:

```cpp
serialize_selected_series(
    {{"now_dead","total"},                       // all-rings aggregate
     {"now_dead","total","<ringname1>"},
     {"now_dead","total","<ringname2>"},
     {"now_dead","total","<ringname3>"},
     {"new_infectious","total","<ringname1>"},
     {"new_infectious","total","<ringname2>"},
     {"new_infectious","total","<ringname3>"}},
    series, "ring_run", {"code","epi_sim","series_output"});
```

Use the real ring names per config (e.g. spreader_ring/sealed_a/sealed_b, or
homebody/mixer/roamer). If names give trouble, the resolver also accepts "1"/"2"/"3"
by index.

## Predicted patterns (confirm or amend)

1. **rings_lowout (all 0.05) vs rings_highout (all 0.60), symmetric.**
   Aggregate epidemic curve: highout should look close to global mixing (rings
   barely matter — everyone mixes out), lowout should run SLOWER and possibly lower
   peak (infection stays bottled in rings, burns local fuel, less reseeding). Per-ring
   deaths in both are ~equal across rings (symmetry). This is your baseline: with
   symmetric migration there is NO inter-ring asymmetry — that's the control.

2. **rings_oneleaky (ring_1=0.20, others 0.00).**
   ring_1 spends infection outward → its INTERNAL death rate should be LOWER than
   ring_2/ring_3, which receive ring_1's exports but can't shed. Expect ring_2 ≈
   ring_3 (symmetric receivers) > ring_1. The protective effect of being the exporter.

3. **rings_one_exporter (spreader_ring=0.80 @20%, two sealed=0.00 @40% each).**
   Sharpest version of #2. The small spreader_ring should have a LOWER per-capita
   death rate than the large sealed rings, despite being the engine of spread. The two
   sealed rings get seeded almost entirely from outside and should show DELAYED onset
   then high death rate. Watch the new_infectious timing: spreader_ring peaks first,
   sealed rings lag.

4. **rings_gradient (homebody 0.02 / mixer 0.30 / roamer 0.70).**
   Monotone test: per-capita death rate should DECREASE as own-export increases —
   roamer lowest, homebody highest — because export = self-protection while the
   homebody both fails to shed and receives others' exports. If the ordering isn't
   monotone, that's the interesting amendment to intuition (e.g. the highest exporter
   might also reseed itself indirectly via the others, flattening the effect).

## Reading tips

- Normalize per-ring deaths by ring population (pct_of_population × popn) before
  comparing — rings differ in size, raw counts mislead.
- The aggregate column should be ~invariant to the in/out SPLIT when total contact
  count is fixed; what changes is the DISTRIBUTION across rings. If the aggregate
  itself moves a lot between symmetric configs, that's a clue migration also changes
  total transmission efficiency (e.g. via depleting vs. reseeding susceptibles),
  which is worth understanding separately from the distributional effect.
- Same seed across runs: with identical seeds the early trajectory should overlay
  until ring structure bites, making the divergence point visible.

## Caveat

These predictions are mechanism-based reasoning about the spread.cpp logic, not
results from runs — I cannot execute the sim. Treat them as hypotheses to check. If
a run contradicts a prediction, the first question is whether the per-ring COLUMNS
are correct (hence the value of the resolve_series unit test) before concluding the
EPIDEMIOLOGY surprised you.
